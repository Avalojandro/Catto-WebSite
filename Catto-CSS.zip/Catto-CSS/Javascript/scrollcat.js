    
    //Catto CSS v.3.20 | 2020 | MIT License | cattoscript.js 
    //A proyect by: Alejandro Avalos | https://github.com/Avalojandro/Catto-CSS
    ///////////////////////////////////////////////////////////////////////////
    //This code was made with waypoints, http://imakewebthings.com/waypoints///
    ///////////////////////////////////////////////////////////////////////////


//s-o-bounce
$(".s-o-bounce").waypoint(function()
{
$(".s-o-bounce").addClass("bounce")
}, {offset:'70%'});

//s-o-surprise
$(".s-o-surprise").waypoint(function()
{
$(".s-o-surprise").addClass("surprise")
}, {offset:'70%'});

//s-o-slideFadeLeft
$(".s-o-slideFadeLeft").waypoint(function()
{
$(".s-o-slideFadeLeft").addClass("slideFadeLeft")
}, {offset:'70%'});

//s-o-slideFadeRight
$(".s-o-slideFadeRight").waypoint(function()
{
$(".s-o-slideFadeRight").addClass("slideFadeRight")
}, {offset:'70%'});

//s-o-slideFadeDown
$(".s-o-slideFadeDown").waypoint(function()
{
$(".s-o-slideFadeDown").addClass("slideFadeDown")
}, {offset:'70%'});

//s-o-slideFadeUp
$(".s-o-slideFadeUp").waypoint(function()
{
$(".s-o-slideFadeUp").addClass("slideFadeUp")
}, {offset:'70%'});

//s-o-blink
$(".s-o-blink").waypoint(function()
{
$(".s-o-blink").addClass("blink")
}, {offset:'70%'});

//s-o-sight
$(".s-o-sight").waypoint(function()
{
$(".s-o-sight").addClass("sight")
}, {offset:'70%'});

//s-o-respite
$(".s-o-respite").waypoint(function()
{
$(".s-o-respite").addClass("respite")
}, {offset:'70%'});

//s-o-heartbeat
$(".s-o-heartbeat").waypoint(function()
{
$(".s-o-heartbeat").addClass("heartbeat")
}, {offset:'70%'});

//s-o-zoomOutRight
$(".s-o-zoomOutRight").waypoint(function()
{
$(".s-o-zoomOutRight").addClass("zoomOutRight")
}, {offset:'70%'});

//s-o-zoomOutLeft
$(".s-o-zoomOutLeft").waypoint(function()
{
$(".s-o-zoomOutLeft").addClass("zoomOutLeft")
}, {offset:'70%'});

//s-o-zoomOutUp
$(".s-o-zoomOutUp").waypoint(function()
{
$(".s-o-zoomOutUp").addClass("zoomOutUp")
}, {offset:'70%'});

//s-o-zoomOutDown
$(".s-o-zoomOutDown").waypoint(function()
{
$(".s-o-zoomOutDown").addClass("zoomOutDown")
}, {offset:'70%'});

//s-o-showRotate
$(".s-o-showRotate").waypoint(function()
{
$(".s-o-showRotate").addClass("showRotate")
}, {offset:'70%'});

//s-o-swing
$(".s-o-swing").waypoint(function()
{
$(".s-o-swing").addClass("swing")
}, {offset:'70%'});

//s-o-jello
$(".s-o-jello").waypoint(function()
{
$(".s-o-jello").addClass("jello")
}, {offset:'70%'});

//s-o-hinge
$(".s-o-hinge").waypoint(function()
{
$(".s-o-hinge").addClass("hinge")
}, {offset:'70%'});

//s-o-slideLeft
$(".s-o-slideLeft").waypoint(function()
{
$(".s-o-slideLeft").addClass("slideLeft")
}, {offset:'70%'});

//s-o-slideRight
$(".s-o-slideRight").waypoint(function()
{
$(".s-o-slideRight").addClass("slideRight")
}, {offset:'70%'});