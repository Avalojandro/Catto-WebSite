# In Progress

Catto-CSS is a recently launched library (January-2020), so with each version new improvements and features will be launched
For this, some of the updates that are being worked on are:

 - npm package creation 
 - Catto-CDN creation 
 - Animation speed settings
 - Jquery animations
 - Configure the animation with javascript

 ## Problems to fix
 >These animations present a couple of failures
 - a-fade
 - i-bounce
 - i-bounceLeft
 - i-bounceRight
 - i-shakeX
 - i-shakeY
 - s-o-surprice


>Remember that you can also collaborate with the production of this project, just follow the instructions in https://github.com/Avalojandro/Work-With-Us-Catto-CSS-#work-with-us-catto-css-
